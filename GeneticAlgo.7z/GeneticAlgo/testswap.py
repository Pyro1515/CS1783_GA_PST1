from random import randint

i = 0
while i < 25:
    print(randint(1,10))
    i += 1
from random import randint
from sys import argv
from os import _exit
import copy, csv

#Adam Apicella
#Chris Sheldon
#Zach Melick

#Genetic Algo
n = None
maxGen = None
pc = None
pm = None

class Schedule:
    #class for a single schedule generated
    def __init__(self, roomList, timeList):
        #throw list of rooms and times of classes into a schedule
        self.sched = makeSchedule(roomList, timeList)
        #get the fitness of the schedule generated and set the fitness to it
        self.fitness = getFit(self)

class Classes:
    #class that generates all the variables for a class "Object"
    def __init__(self, crn, course, prof, courseSize, needMultimedia, room, time): #self is equiv to java "this"
        self.crn = crn
        self.course = course
        self.prof = prof
        self.courseSize = courseSize
        self.needMultimedia = bool(needMultimedia)
        self.room = room
        self.time = time
    

class Room:
    #class that generates all the variables for a room "Object"
    def __init__(self, roomNum, roomSize, multimedia):
        self.roomNum = roomNum
        self.roomSize = roomSize
        self.multimedia = bool(multimedia)


class Times:
    #Sets up an "Object" that holds a periodId, Days of the week and times that classes can take place
    def __init__(self, periodID, days, time):
        self.periodID = periodID
        self.days = days
        self.time = time

def makeSchedule(roomList, timeList):
    #generate a random schedule from all the data
    temp = []
    #temp array for holding a generated schedule
    with open("ClassInfo.csv") as csvfile:
        readCSV = csv.reader(csvfile, delimiter=',')
        firstline = True
        for row in readCSV:
            if firstline:    #skip first line
                firstline = False
                continue
                #for each line in the classInfo file, take teh class and give it a random room number and time on the schedule
            temp.append(Classes(row[0], row[1], row[2], int(row[3]), row[4], roomList[randint(0,8)], timeList[randint(0,13)]))
    return temp

def loadTimes():
    #generate an array with period numbers, days of the week and times the classes will take place
    temp = []
    with open("TimeSlotInfo.csv") as csvfile:
        readCSV = csv.reader(csvfile, delimiter=',')
        firstline = True
        for row in readCSV:
            if firstline:    #skip first line
                firstline = False
                continue
                #add these periods, days and times to an array, each set will be its own thing
            temp.append(Times(row[0], row[1], row[2]))
    return temp

def loadRooms():
    #generate an array with rooms, its size and if there is multimedia in it (is a boolean)
    temp = []
    with open("RoomInfo.csv") as csvfile:
        readCSV = csv.reader(csvfile, delimiter=',')
        firstline = True
        for row in readCSV:
            if firstline:
                firstline = False
                continue
                #add the room, size and boolean to an array, each set is its own thing
            temp.append(Room(row[0], int(row[1]), row[2]))
    return temp

def battleToTheDeath(population):
    #Tournament based algorithm, 2 random schedules are chosen and the one with the higher fitness moves on to be a parent
    rand1 = randint(0, (len(population) - 1))
    rand2 = randint(0, (len(population) - 1))
    if rand2 == rand1:
        #rechoose if both chosen are the same "person"
        rand2 = randint(0, (len(population) - 1))
    if population[rand1].fitness > population[rand2].fitness:
        #choose the winner
        parent = population[rand1] 
    else:
        #again, choose the winner if the if statement was false
        parent = population[rand2]

    return parent

def newGen(currentGen, rooms, times):
    #create the next generation using the previous generation
    nextGen = []
    i = 0
    while i < (len(currentGen)/2):
        #take the 2 parents chosent from tournament and deep copy them
        parent1 = copy.deepcopy(battleToTheDeath(currentGen))
        parent2 = copy.deepcopy(battleToTheDeath(currentGen))
        if randint(1, 100) < pc:
            #get a random number and if it is lower than the crossover rate chosen then begin crossover
            crossover = randint(0,26)
            #select the random number of things that will change
            #make a temp so data is not lost
            temp = copy.deepcopy(parent1)
            
            while crossover < 27:
                #cross over data from 2 into 1 and temp into 2
                parent1.sched[crossover] = parent2.sched[crossover]
                parent2.sched[crossover] = temp.sched[crossover]
                #continue until random number chosen reaches 27
                crossover += 1
                
        for x in parent1.sched: 
            if randint(1,100) < pm:
                #get a random number and if it is lower than the mutation rate chosen then begin mutation
                rand1 = randint(0,8)
                rand2 = randint(0,13)
                #select random numbers for room and time of class
                #change the current room and time of class with the newly found time and class
                x.room = rooms[rand1]
                x.time = times[rand2]

        for x in parent2.sched: 
            #same process as last 3 comments, look up a few lines and repeat
            if randint(1,100) < pm:
                rand1 = randint(0,8)
                rand2 = randint(0,13)
                x.room = rooms[rand1]
                x.time = times[rand2]

        #get the fitness of both parents and add them to the next generation
        parent1.fitness = getFit(parent1)
        parent2.fitness = getFit(parent2)
        nextGen.append(parent1)
        nextGen.append(parent2)
        i += 1
    return nextGen

def getFit(scheduleObj):
    temp = 0
    profchecked = []
    roomchecked = []
    #determine fitness using certain criteria
    for x in scheduleObj.sched:
        if x.needMultimedia == True and x.room.multimedia == False: #does the room need media and not have it? -50
            temp -= 50
        if x.needMultimedia == True and x.room.multimedia == True:  #does the room need media and get it? +20
            temp += 20
        if x.courseSize > x.room.roomSize: #are there too many students for the room? -70\
            temp -= 70
        if x.courseSize <= x.room.roomSize:#will the students fit in the room? +20
            temp += 20
        for y in scheduleObj.sched:
            if x in profchecked:
                pass
            elif (x != y) and (x.time == y.time) and (x.prof == y.prof):
                profchecked.append(x)
                if y in profchecked:
                    pass
                else:
                    profchecked.append(y)
        if len(profchecked) > 0: #professor is teaching more than 1 course at the same time? -300
            temp -= 300
        for y in scheduleObj.sched:
            if x in roomchecked:
                pass
            elif(x != y) and (x.time == y.time) and (x.room == y.room):
                roomchecked.append(x)
                if y in roomchecked:
                    pass
                else:
                    roomchecked.append(y)
        if len(roomchecked) >= 3: # are 3 classes schduled in the same room at the same time? -600
            temp -= 600
        elif len(roomchecked) > 0:# is more than 1 class scheduled in the same room at the same time? -300
            temp -= 300
    return temp

if __name__ == "__main__":
    if len(argv) is not 5:
        print('To run: python GeneticAlgo.py popSize maxGen crossOverRate(0.0 - 1.00) mutationRate(0.00 - 1.00)')
        _exit(1)

    n = int(argv[1])
    maxGen = int(argv[2])
    pc = float(argv[3]) * 100
    pm = float(argv[4]) * 100


    #load all the rooms and times into usable lists
    roomList = loadRooms()
    timeList = loadTimes()

    population = []
    
    i = 0
    while i < n:
        #create the first generation of schedules
        population.append(Schedule(roomList, timeList))        
        i += 1
    
    j = 0
    generation = 1
    file = open("log.txt", 'w')
    while generation < maxGen:
        temp = population[0]
        for x in population:
            if x.fitness > temp.fitness:
                temp = x

        bestFit = copy.deepcopy(temp)
        out = ""
        if generation%100 == 0:
            out = "XXXXXXXXXXXXXX Generation" + str(generation) + "XXXXXXXXXXXXXX\n"
            file.write(out)
            print(out)
            for x in population:
                file.write("--------------------Next Sched-----------------------\n")
                print("--------------------Next Sched-----------------------")
                for y in x.sched:

                    out = y.crn + " " + y.course + " " + y.prof + " " + str(y.courseSize) + " " + str(y.needMultimedia) + '|' + y.room.roomNum  + " " + str(y.room.roomSize) + " " + str(y.room.multimedia) + '|' + y.time.days + " " + y.time.time + "\n"
                    file.write(out)
                    print(y.crn,y.course,y.prof,y.courseSize,y.needMultimedia,'|', y.room.roomNum,y.room.roomSize,y.room.multimedia,'|',y.time.days,y.time.time)
                print("\n")
            file.write(str(bestFit.fitness))
            print(bestFit.fitness)
        if bestFit.fitness == 820:
            break
        generation += 1
        population = newGen(population, roomList, timeList)
    file.write("--------------------Best Sched-----------------------\n")
    print("--------------------Best Sched-----------------------")
    for y in bestFit.sched:
        out = y.crn + " " + y.course + " " + y.prof + " " + str(y.courseSize) + " " + str(y.needMultimedia) + '|' + y.room.roomNum  + " " + str(y.room.roomSize) + " " + str(y.room.multimedia) + '|' + y.time.days + " " + y.time.time + "\n"
        file.write(out)
        print(y.crn,y.course,y.prof,y.courseSize,y.needMultimedia,'|', y.room.roomNum,y.room.roomSize,y.room.multimedia,'|',y.time.days,y.time.time)
    out = "------------------- Fitness" + str(getFit(bestFit)) + "----------------------"
    file.write(out)
    print("------------------- Fitness", getFit(bestFit),"----------------------")
    out = "\n Generations Required: " + str(generation)
    file.write(out)
    print("\n Generations Required: ", generation)
    file.close()